<template>
  <v-app id="app">
    <v-container fluid>
      <v-layout class="" row wrap justify-start>
        <v-flex class="">
            <div class="p-date">
                <span class="display-3">{{date.h}}</span>じ <span class="display-3">{{date.m}}</span>ふん <span class="display-3">{{date.s}}</span>びょう
                <span> / </span>
                <span class="display-1">{{date.Y}}</span>ねん <span class="display-1">{{date.M}}</span>がつ <span class="display-1">{{date.D}}</span>にち
            </div>
        </v-flex>
      </v-layout>
      <v-layout class="" row wrap>
        <v-draggable class="drag-container">
            <v-flex @click="toggle_complete(item.id)" class="pa-3" xs4 v-for="(item, index) in items" :key="item.id" grow shrink>
                <li class="p-btn" :id="item.id">
                    {{item.name}}-(No.{{item.id}}) {{item.finish}}
                        <div class="p-btn_index">{{index+1}}</div>
                        <div class="p-btn_finished" v-if="item.finish">
                            <v-layout align-center justify-center fill-height>
                                <v-icon color="#fff" size="60">check</v-icon>
                            </v-layout>
                        </div>
                    
                </li>
            </v-flex>
        </v-draggable>
      </v-layout>
      <v-layout class="" row wrap>
        <v-flex xs12>
            <v-slider
                label="制限時間"
                thumb-label="always"
                thumb-size="40"
                max="30"
                prepend-icon="timer"
                v-model="limit"
                v-bind:value="limit">
            </v-slider>
        </v-flex>
        <v-flex xs12>
            <v-slider
                label="経過時間"
                thumb-label="always"
                thumb-size="40"
                color="orange"
                max="1800" 
                height="50"
                prepend-icon="timer"
                v-model="elapsed"
                v-bind:value="elapsed" readonly>
            </v-slider>
            <div>{{elapsed}}</div>
        </v-flex>

        <v-flex xs12>
            <v-btn @click="start_timer">START</v-btn>
            <v-btn @click="stop_timer">STOP</v-btn>
        </v-flex>
      </v-layout>
    </v-container>
  </v-app>
</template>

<script>

//Vue Component
// import TaskCard from './TaskCard';
import Draggable from 'vuedraggable';
import moment from 'moment';
import _ from 'lodash';
import { setInterval, clearInterval } from 'timers';

// @ is an alias to /src
// import HelloWorld from '@/components/HelloWorld.vue'

var timer = "";

export default {
  name: 'home',
  created:function () {
      var _this = this;
      setInterval(function(){
          _this.date.Y = moment().format('YYYY');
          _this.date.M = moment().format('MM');
          _this.date.D = moment().format('DD');
          _this.date.h = moment().format('HH');
          _this.date.m = moment().format('mm');
          _this.date.s = moment().format('ss');
      },1000);
  },
  components: {
      // "v-taskcard": TaskCard,
      "v-draggable": Draggable
  },
  methods: {
      toggle_complete:function(id){
        var _this = this;
        var _idx = _.findIndex(_this.items, {'id':id});
        _this.items[_idx].finish = !_this.items[_idx].finish;
      },
      start_timer:function(){
        var _this = this;
        _this.start_time = moment();
        timer = setInterval(function(){
          _this.elapsed = moment().diff(_this.start_time,'seconds');
        },1000)
      },
      stop_timer:function(){
          clearInterval(timer);
      }
  },
  data:function(){
      return{
          limit:0,
          elapsed:0,
          start_time:0,
          date:{
              h:0,
              m:0,
              s:0,
              Y:0,
              M:0,
              D:0
          },
          items:[
              {id:1, name:'キャベツ', finish:false},
              {id:2, name:'ステーキ', finish:false},
              {id:3, name:'リンゴ', finish:false},
              {id:4, name:'キャベツ', finish:false},
              {id:5, name:'ステーキ', finish:false},
              {id:6, name:'リンゴ', finish:false}
          ]
      }
  }
}
</script>

<style lang="scss" scoped>
.p-btn{
    background:#eee;
    display:flex;
    align-items: center;
    justify-content: center;
    width: 100%;
    height: 100%;
    border-radius:4px;
    padding: 80px 0;
    position: relative;
    cursor: pointer;
    transition:all ease 0.3s;
    &:hover{
        opacity:0.75;
    }
    &_index{
        width: 40px;
        height: 40px;
        color:#fff;
        font-size: 28px;
        font-weight: bold;
        background:rgba(255, 127, 50, 0.87);
        border-radius:50%;
        position: absolute;
        line-height: 40px;
        top: 0;
        left: 0;
        margin-top: -10px;
        margin-left:-10px;
    }
    &_finished{
        width: 80px;
        height: 80px;
        background:rgba(76, 175, 80, 0.87);
        border-radius:50%;
        position: absolute;
        top: 50%;
        left: 50%;
        margin-top: -40px;
        margin-left:-40px;
    }
}
.p-date{
    font-size: 18px;
    span{
        font-weight: 600;
        margin-right: 0.1em;
    }
}

.drag-container{
    display: flex;
    width: 100%;
    flex-flow:row wrap;
}
</style>
